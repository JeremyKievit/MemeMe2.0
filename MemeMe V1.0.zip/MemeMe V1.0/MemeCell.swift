//
//  MemeCell.swift
//  MemeMe V1.0
//
//  Created by admin on 9/26/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import UIKit

class MemeCell: UICollectionViewCell {
    @IBOutlet weak var memeImage: UIImageView!
}
